public class ShapeInterface {
}
